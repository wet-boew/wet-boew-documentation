// Data structure example for a working chat wizard
var botapi = function() {
	var datainput = {
	header: {
		formType: "dynamic",
		defaultDestination: "page1.html",
		first: "q1",
		title: "I can help you find the information you need",
		instructions: "First, if you are an employer or organization looking for funding, you can find relevant information on the <a href='pagex.html'>funding page</a>.",
		sendBtn: "Show results",
		greetings: "Hi! I can help direct you to programs and services you might be interested in. Let\'s begin...",
		farewell: "Thank you. I have built a page with results you may find resourceful.",
		form: {
			title: "Help us help you",
			instructions: "If you are an employer or organization looking for funding, you can find relevant information on the <a href='pagex.html'>funding page</a>.",
			sendBtn: "Search"
		}
	}, 
	questions: {
		q1: 
		{
			name: "describe",
			input: "radio",
			label: "Are you:",
			formLabel: "What would you describe yourself as?",
			choices: [
				{ 
					content: "a young Canadian",
					value: "young-canadian",
					next: "q2"
				},
				{ 
					content: "an employer or organization looking for funding to support youth",
					value: "employer-organization-funding-support-youth",
					next: "none",
					url: "results-en.html"
				}
			]
		}, 
		q2:
		{
			name: "situation",
			input: "radio",
			label: "Great! And are you:",
			formLabel: "In what situation are you?",
			choices: [
				{ 
					content: "a high school student",
					value: "high-school",
					next: "q3"
				},
				{ 
					content: "a CÉGEP student",
					value: "cegep-student",
					next: "q3"
				},
				{ 
					content: "a post-secondary school student",
					value: "post-secondary",
					next: "q3"
				},
				{ 
					content: "ready to start a career",
					value: "ready-start-career",
					next: "q3"
				},
				{ 
					content: "not in school and not working",
					value: "not-school-not-working",
					next: "q3"
				},
				{ 
					content: "none of these",
					value: "none",
					next: "q3"
				}
			]
		},
		q3:
		{
			name: "goal",
			input: "radio",
			label: "Awesome! Finally, would you like to:",
			formLabel: "What is your goal?",
			choices: [
				{ 
					content: "get a job",
					value: "get-job",
					next: "none",
					url: "results-en.html"
				},
				{ 
					content: "develop skills",
					value: "develop-skills",
					next: "none",
					url: "results-en.html"
				},
				{ 
					content: "explore careers",
					value: "explore-careers",
					next: "none",
					url: "results-en.html"
				},
				{ 
					content: "attend post-secondary education",
					value: "post-secondary-education",
					next: "none",
					url: "results-en.html"
				},
				{ 
					content: "serve your community",
					value: "serve-community",
					next: "none",
					url: "results-en.html"
				},
				{ 
					content: "get an experience",
					value: "get-experience",
					next: "none",
					url: "results-en.html"
				},
				{ 
					content: "see everything",
					value: "everything",
					next: "none",
					url: "results-en.html"
				}
			]
		}
	}
	};
	return datainput;
}